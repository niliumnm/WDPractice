#pragma once
#include <libremidi/config.hpp>

namespace libremidi
{

struct emscripten_input_configuration
{
};
struct emscripten_output_configuration
{
};
struct emscripten_observer_configuration
{
};

}
