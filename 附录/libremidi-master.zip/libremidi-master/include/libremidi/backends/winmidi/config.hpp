#pragma once
#include <libremidi/config.hpp>

namespace libremidi::winmidi
{

struct input_configuration
{
};

struct output_configuration
{
};

struct observer_configuration
{
};

}
