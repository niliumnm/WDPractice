#pragma once
#include "../utils.hpp"

namespace libremidi
{

}
