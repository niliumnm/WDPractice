#if __has_include(<catch2/catch_all.hpp>)
  // Catch 2 v3
  #include <catch2/catch_all.hpp>
#else
  // Catch 2 v2
  #include <catch2/catch.hpp>
#endif
#include <fstream>
#include <iostream>
